<header class="header">
    <div class="container">
        <div class="logo">
            <h1>📄 Gestion Documents</h1>
        </div>
        <nav class="nav-links">
            <a href="dashboard.php">🏠 Tableau de bord</a>
            
            <?php if(isAdmin()): ?>
                <a href="admin/users.php">👥 Utilisateurs</a>
                <a href="admin/departments.php">🏢 Départements</a>
                <a href="admin/documents.php">📁 Tous les docs</a>
            <?php else: ?>
                <a href="user/documents.php">📁 Mes documents</a>
            <?php endif; ?>
            
            <a href="logout.php" class="btn-logout">🚪 Déconnexion</a>
        </nav>
    </div>
</header>