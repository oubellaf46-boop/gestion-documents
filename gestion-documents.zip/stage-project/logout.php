<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if(isset($_SESSION['user_id'])) {
    logActivity($_SESSION['user_id'], 'logout', 'Déconnexion');
}

session_destroy();
header("Location: login.php");
exit();
?>