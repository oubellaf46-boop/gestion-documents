<?php
session_start();

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
        }
        .header {
            background: #1a2a6c;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 24px; }
        .header a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            background: #e74c3c;
            border-radius: 5px;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }
        .welcome {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .welcome h2 { color: #1a2a6c; }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .stat-card h3 { color: #7f8c8d; font-size: 14px; }
        .stat-card .number { font-size: 32px; font-weight: bold; color: #1a2a6c; }
        .actions {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .actions a {
            display: inline-block;
            padding: 10px 20px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 5px;
        }
        .actions a:hover { opacity: 0.8; }
    </style>
</head>
<body>
    <div class="header">
        <h1>📄 Gestion de Documents</h1>
        <div>
            Bonjour, <?php echo htmlspecialchars($_SESSION['user_full_name'] ?? 'Utilisateur'); ?>
            <a href="logout.php">Déconnexion</a>
        </div>
    </div>
    
    <div class="container">
        <div class="welcome">
            <h2>Bienvenue sur votre tableau de bord !</h2>
            <p>Vous êtes connecté en tant que <?php echo $_SESSION['user_role'] ?? 'utilisateur'; ?></p>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <h3>Total Documents</h3>
                <p class="number">0</p>
            </div>
            <div class="stat-card">
                <h3>Vos Documents</h3>
                <p class="number">0</p>
            </div>
        </div>
        
        <div class="actions">
            <h3>Actions Rapides</h3>
            <a href="#">📤 Uploader un document</a>
            <a href="#">📁 Voir mes documents</a>
            <?php if($_SESSION['user_role'] === 'admin'): ?>
                <a href="#">👥 Gérer les utilisateurs</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>