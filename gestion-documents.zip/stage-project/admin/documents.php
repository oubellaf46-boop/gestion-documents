<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

if(!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Traitement upload
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_document'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $document_type = $_POST['document_type'];
    $department_id = !empty($_POST['department_id']) ? $_POST['department_id'] : null;
    $status = $_POST['status'];
    
    if(isset($_FILES['document_file']) && $_FILES['document_file']['error'] === 0) {
        $upload_result = uploadFile($_FILES['document_file'], $document_type);
        
        if($upload_result['success']) {
            $stmt = $pdo->prepare("INSERT INTO documents (document_type, title, description, file_name, file_path, file_size, file_type, department_id, uploaded_by, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            $result = $stmt->execute([
                $document_type,
                $title,
                $description,
                $upload_result['file_name'],
                $upload_result['file_path'],
                $_FILES['document_file']['size'],
                $_FILES['document_file']['type'],
                $department_id,
                $_SESSION['user_id'],
                $status
            ]);
            
            if($result) {
                $document_id = $pdo->lastInsertId();
                logActivity($_SESSION['user_id'], 'upload_document', "Upload du document: $title (ID: $document_id)");
                $success = "Document uploadé avec succès!";
            } else {
                $error = "Erreur lors de l'enregistrement du document.";
            }
        } else {
            $error = $upload_result['message'];
        }
    } else {
        $error = "Veuillez sélectionner un fichier.";
    }
}

// Récupérer tous les documents
$documents = $pdo->query("
    SELECT d.*, u.full_name as uploaded_by_name, dep.name as department_name 
    FROM documents d 
    LEFT JOIN users u ON d.uploaded_by = u.id 
    LEFT JOIN departments dep ON d.department_id = dep.id 
    ORDER BY d.upload_date DESC
")->fetchAll();

// Récupérer départements
$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Documents - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <h1>📁 Gestion des Documents</h1>
        
        <?php if(isset($success)): ?>
            <div class="alert alert-success">✅ <?php echo $success; ?></div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
            <div class="alert alert-error">❌ <?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>📤 Uploader un nouveau document</h2>
            <form method="POST" enctype="multipart/form-data" class="upload-form">
                <div class="form-row">
                    <div class="form-group">
                        <label>Type de document *</label>
                        <select name="document_type" required>
                            <option value="check">Chèque</option>
                            <option value="invoice">Facture</option>
                            <option value="contract">Contrat</option>
                            <option value="other">Autre</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Département</label>
                        <select name="department_id">
                            <option value="">Aucun</option>
                            <?php foreach($departments as $dept): ?>
                                <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Titre *</label>
                    <input type="text" name="title" required placeholder="Ex: Facture fournisseur Mars 2026">
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" placeholder="Description du document..."></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Statut</label>
                        <select name="status">
                            <option value="active">Actif</option>
                            <option value="archived">Archivé</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Fichier *</label>
                        <input type="file" name="document_file" required>
                        <small>Types autorisés: PDF, DOC, DOCX, JPG, PNG, XLS, XLSX (Max 10MB)</small>
                    </div>
                </div>
                
                <button type="submit" name="upload_document" class="btn btn-primary">📤 Uploader</button>
            </form>
        </div>
        
        <div class="card">
            <h2>📋 Tous les documents</h2>
            <?php if(empty($documents)): ?>
                <p>Aucun document trouvé.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type</th>
                                <th>Titre</th>
                                <th>Département</th>
                                <th>Uploadé par</th>
                                <th>Taille</th>
                                <th>Date</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($documents as $doc): ?>
                            <tr>
                                <td><?php echo $doc['id']; ?></td>
                                <td><span class="badge badge-<?php echo $doc['document_type']; ?>"><?php echo ucfirst($doc['document_type']); ?></span></td>
                                <td><?php echo htmlspecialchars($doc['title']); ?></td>
                                <td><?php echo htmlspecialchars($doc['department_name'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($doc['uploaded_by_name']); ?></td>
                                <td><?php echo formatFileSize($doc['file_size']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($doc['upload_date'])); ?></td>
                                <td><span class="badge badge-<?php echo $doc['status']; ?>"><?php echo $doc['status']; ?></span></td>
                                <td class="actions">
                                    <a href="view_document.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-info">👁️</a>
                                    <a href="edit_document.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-warning">✏️</a>
                                    <a href="delete_document.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression?')">🗑️</a>
                                    <a href="<?php echo $doc['file_path']; ?>" target="_blank" class="btn btn-sm btn-success">📥</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>