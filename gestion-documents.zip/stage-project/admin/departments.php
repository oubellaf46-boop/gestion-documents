<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

if(!isLoggedIn() || !isAdmin()) {
    header("Location: ../login.php");
    exit();
}

// Créer un département
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_department'])) {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO departments (name, description) VALUES (?, ?)");
        $stmt->execute([$name, $description]);
        logActivity($_SESSION['user_id'], 'create_department', "Création du département: $name");
        $success = "Département créé avec succès!";
    } catch(PDOException $e) {
        $error = "Erreur: " . $e->getMessage();
    }
}

// Supprimer un département
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM departments WHERE id = ?");
        $stmt->execute([$id]);
        logActivity($_SESSION['user_id'], 'delete_department', "Suppression du département ID: $id");
        $success = "Département supprimé!";
    } catch(PDOException $e) {
        $error = "Impossible de supprimer ce département (peut-être utilisé par des documents)";
    }
}

$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Départements</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <h1>🏢 Gestion des Départements</h1>
        
        <?php if(isset($success)): ?>
            <div class="alert alert-success">✅ <?php echo $success; ?></div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
            <div class="alert alert-error">❌ <?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>➕ Créer un département</h2>
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Nom *</label>
                        <input type="text" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <input type="text" name="description">
                    </div>
                </div>
                <button type="submit" name="create_department" class="btn btn-primary">➕ Créer</button>
            </form>
        </div>
        
        <div class="card">
            <h2>📋 Liste des départements</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Date création</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($departments as $dept): ?>
                        <tr>
                            <td><?php echo $dept['id']; ?></td>
                            <td><?php echo htmlspecialchars($dept['name']); ?></td>
                            <td><?php echo htmlspecialchars($dept['description'] ?? 'N/A'); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($dept['created_at'])); ?></td>
                            <td class="actions">
                                <a href="?delete=<?php echo $dept['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression?')">🗑️</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>