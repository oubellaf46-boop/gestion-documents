# Gestion de Documents

A web-based document management application built with **PHP** and **MySQL**, developed during a one-month internship at **PARADISOFT SARL AU** (Tangier, Morocco), as part of my first year in Computer Science and Digital Development at **ESTT** (Higher School of Technology of Tétouan).

## About

The app lets a team upload, organize, and control access to internal documents (checks, invoices, contracts, and more), with two access levels: administrator and standard user.

- **Duration:** July 15 – August 15, 2026
- **Company:** PARADISOFT SARL AU, Tangier
- **Professional supervisor:** Mr. Youssef EL KHANNOUS
- **Academic supervisor:** Mrs. Ouazri Chaimae

## Features

- Secure login with hashed passwords (`password_hash` / `password_verify`) and PHP sessions
- Role-based access control (admin / standard user)
- Document upload with type, department, and status metadata
- Department management (create / list / delete)
- User management (create / list)
- Activity logging for key actions

## Tech stack

- PHP (procedural, PDO for database access)
- MySQL
- HTML5 / CSS3 (no frontend framework)
- All database queries use **prepared statements** to prevent SQL injection

## Project structure

```
.
├── index.php               # Redirects to login.php
├── login.php                # Login form + authentication
├── logout.php                # Destroys the session
├── dashboard.php           # Landing page after login
├── admin/
│   ├── users.php            # User management (admin only)
│   ├── departments.php      # Department management (admin only)
│   └── documents.php        # Document management (admin only)
├── includes/
│   ├── header.php
│   ├── footer.php
│   └── functions.php        # isLoggedIn(), isAdmin(), logActivity(), etc.
├── config/
│   └── database.php         # PDO connection (edit with your DB credentials)
├── database/
│   └── schema.sql           # Table structure + a default admin account
└── assets/
    └── css/style.css
```

## Setup

1. Create a MySQL database and import the schema:
   ```bash
   mysql -u root -p -e "CREATE DATABASE gestion_docs"
   mysql -u root -p gestion_docs < database/schema.sql
   ```
2. Update `config/database.php` with your database credentials.
3. Serve the project with PHP's built-in server (or place it in your local web server's document root):
   ```bash
   php -S localhost:8000
   ```
4. Visit `http://localhost:8000/login.php` and sign in with the default admin account: `admin` / `password`.

## Known limitations

This was an introductory, one-month project — a few things are intentionally left as next steps:

- The pages for viewing/editing a single document or user (`view_document.php`, `edit_document.php`, `delete_document.php`, `edit_user.php`, `delete_user.php`) and the standard-user document view (`user/documents.php`) are linked from the interface but not yet implemented.
- `dashboard.php` still uses inline styles rather than the shared `assets/css/style.css`.
- The dashboard's document counts are currently static placeholders rather than live queries.

## Acknowledgments

Thanks to Mr. Youssef EL KHANNOUS and the PARADISOFT team for their guidance and trust during my first professional experience, and to Mrs. Ouazri Chaimae for her support throughout the internship.

## Author

**Oubella Fatima Zahra**
Computer Science & Digital Development student, ESTT
